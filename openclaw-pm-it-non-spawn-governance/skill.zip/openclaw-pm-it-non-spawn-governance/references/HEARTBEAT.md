# HEARTBEAT.md

## Purpose

Heartbeat is a lightweight nudge mechanism. It is not a scheduler replacement.

Use heartbeat for:
- waking PM or IT to continue the current session
- ensuring a session checks for pending context at regular intervals
- short feedback loops inside an active agent session

Do not use heartbeat as the only mechanism for:
- recurring operational monitoring
- infrastructure health checks
- stability watches that must survive gateway instability
- delayed execution that must happen even when the session is idle or unhealthy

## Recommended heartbeat defaults

### PM (`main`)
Recommended:
- `every: 30m`
- `target: last`

Reason:
- PM should revisit the most recent active context when still coordinating work.

### IT (`it`)
Recommended:
- `every: 30m`
- `target: none`

Reason:
- IT should not wander across session history.
- IT should act only on explicit task context and shared_pool truth.

## Cron vs heartbeat

### Use heartbeat when
- the same session must re-check its current context
- the action is conversational or lightweight
- the session is already alive and healthy

### Use OpenClaw cron when
- work must run on a schedule
- the run must persist across gateway restarts
- you need explicit jobs, run history, and due times
- you want an isolated or main-session scheduled wakeup

### Use external watchdog when
- gateway health itself is in question
- the operator needs checks even if OpenClaw cron is unhealthy
- you need system-level restart, alerting, or exit-code based monitoring

## Recommended layering

1. heartbeat for conversational continuity
2. OpenClaw cron for internal recurring checks
3. systemd timer watchdog for external fallback

## Worker stability checks

For worker-related incidents, the watchdog should look for:
- new `missing status.json`
- repeated `accepted and moved` for the same task id
- lock not being exercised when concurrency is induced
- nested task directories or orphaned task shells

## Closure rule

Do not close a worker stability incident based only on heartbeat behavior.

Close only when:
- a clean log window is defined
- no new worker-pathology patterns appear in that window
- directory checks are clean
- the watchdog or manual equivalent confirms stability
