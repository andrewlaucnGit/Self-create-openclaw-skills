# Incident Closure Checklist

## Worker stability closure

Close only when all checks pass in a declared post-fix window:

1. no new `missing status.json`
2. no repeated `accepted and moved` for the same task id
3. lock behavior verified at least once after the fix
4. no nested or orphaned task directories
5. no cross-task artifact references remain
6. no repeated use of cleanup or persistence recovery scripts for the same pathology

## Hygiene cleanup closure

Close only when:
- quarantine directory exists
- candidate list includes reason and risk
- rollback instructions exist
- live worker and gateway paths remain intact
- service/timer checks are healthy

## Quarantine final disposition closure

Close only when:
- first deletion batch is explicitly listed
- preserved items are explicitly listed
- post-delete validation is successful
- remaining quarantine contents are intentional
