---
name: openclaw-pm-it-non-spawn-governance
description: configure and operate a non-spawn pm-it multi-agent pattern for openclaw where shared_pool is the formal task source of truth and agent-to-agent is used only for constrained pm-to-it communication. use when setting up or hardening an openclaw deployment that needs a pm main agent, an it execution agent, clear task.md/status.json/delivery.md governance, agents.md and heartbeat.md operating rules, and reusable configuration guidance without using sessions_spawn.
---

Implement and verify a reusable OpenClaw operating model where `main` acts as PM, `it` acts as the execution agent, `shared_pool` remains the formal task truth source, and agent-to-agent communication is constrained to PM→IT messaging without `sessions_spawn`.

## Core model

Apply these rules consistently:

1. Treat `shared_pool` as the task system of record.
   - `task.md` defines intent and scope.
   - `status.json` records machine-readable state.
   - `delivery.md` records execution evidence.
2. Use agent-to-agent only as a control-plane supplement.
   - PM may inspect sessions and send messages to IT.
   - IT must not initiate lateral session traffic.
   - Do not rely on `sessions_spawn`.
3. Separate conversation continuity from execution truth.
   - Heartbeat keeps sessions alive.
   - `shared_pool` files determine task truth.
4. Prefer small, verifiable infrastructure changes.
   - Add locks before redesigning flow control.
   - Quarantine before deleting old backups or disabled artifacts.
   - Close incidents only after a clean post-fix log window.

## Included resources

- `references/AGENTS.md`: PM and IT governance rules.
- `references/HEARTBEAT.md`: heartbeat, cron, and stability guidance.
- `references/openclaw-json.non-spawn.template.json`: minimal non-spawn template.
- `references/incident-closure-checklist.md`: closure checklist.
- `scripts/validate_non_spawn_topology.sh`: validates the required topology.

## How to use

### 1. Configure the PM/IT topology

Read `references/openclaw-json.non-spawn.template.json` and adapt it.

Required model:
- `main` is PM.
- `it` is IT.
- top-level `tools.agentToAgent.enabled=true` with `allow=["main","it"]`.
- top-level `tools.sessions.visibility="all"`.
- PM allows `sessions_list`, `sessions_history`, `sessions_send`, and `session_status`.
- PM denies `sessions_spawn`.
- IT denies `sessions_send`, `sessions_spawn`, `sessions_history`, and `session_status`.
- keep `gateway.bind="loopback"` unless there is a tested reason to change it.

### 2. Apply governance rules

Read `references/AGENTS.md` and `references/HEARTBEAT.md` and treat them as required operating standards.

Critical standards:
- PM must report based on evidence, not intentions.
- IT must produce changed files, validation commands, and rollback paths when changing infrastructure.
- heartbeat is not a substitute for cron.
- cron is not a substitute for the external watchdog.

### 3. Validate the deployment

Run:

```bash
bash scripts/validate_non_spawn_topology.sh /root/.openclaw/openclaw.json
```

The deployment is valid only when the script confirms:
- PM may message but not spawn.
- IT cannot initiate session traffic.
- agent-to-agent is limited to `main` and `it`.
- `gateway.bind` remains `loopback`.

### 4. Close incidents only after a clean window

Read `references/incident-closure-checklist.md`.

Minimum closure pattern:
- define the exact log window
- check for no new `missing status.json`
- check for no repeated `accepted and moved` for the same task id
- confirm lock behavior still works
- confirm no bad task shells or nested task directories remain
