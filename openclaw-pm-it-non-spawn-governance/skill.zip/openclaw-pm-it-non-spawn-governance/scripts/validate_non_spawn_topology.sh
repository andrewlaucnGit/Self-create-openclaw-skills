#!/usr/bin/env bash
set -euo pipefail

CFG="${1:-}"
if [[ -z "$CFG" || ! -f "$CFG" ]]; then
  echo "usage: $0 <path-to-openclaw.json>"
  exit 1
fi

python3 - <<'PY' "$CFG"
import json, sys
p = sys.argv[1]
with open(p, 'r', encoding='utf-8') as f:
    cfg = json.load(f)

errors = []

agents = {a.get('id'): a for a in cfg.get('agents', {}).get('list', [])}
main = agents.get('main')
it = agents.get('it')
if not main:
    errors.append('missing agent main')
if not it:
    errors.append('missing agent it')

tools = cfg.get('tools', {})
a2a = tools.get('agentToAgent', {})
if not a2a.get('enabled'):
    errors.append('tools.agentToAgent.enabled must be true')
allow = set(a2a.get('allow', []))
for req in ('main', 'it'):
    if req not in allow:
        errors.append(f'tools.agentToAgent.allow missing {req}')

sessions = tools.get('sessions', {})
if sessions.get('visibility') != 'all':
    errors.append('tools.sessions.visibility should be all for PM->IT session targeting')

if main:
    mtools = main.get('tools', {})
    for req in ('sessions_list', 'sessions_history', 'sessions_send', 'session_status'):
        if req not in mtools.get('allow', []):
            errors.append(f'main.tools.allow missing {req}')
    if 'sessions_spawn' not in mtools.get('deny', []):
        errors.append('main.tools.deny should include sessions_spawn')

if it:
    itools = it.get('tools', {})
    for req in ('sessions_send', 'sessions_spawn', 'sessions_history', 'session_status'):
        if req not in itools.get('deny', []):
            errors.append(f'it.tools.deny missing {req}')

bind = cfg.get('gateway', {}).get('bind')
if bind != 'loopback':
    errors.append('gateway.bind should remain loopback in the non-spawn pattern unless explicitly tested otherwise')

if errors:
    print('INVALID')
    for e in errors:
        print('-', e)
    sys.exit(1)

print('VALID')
print('- main and it are defined')
print('- agentToAgent is enabled for main and it')
print('- sessions visibility is all')
print('- main may message but not spawn')
print('- it cannot initiate session traffic')
print('- gateway.bind is loopback')
PY
