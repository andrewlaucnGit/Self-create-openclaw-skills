---
name: openclaw-cron-watchdog-ubuntu
description: install and operate a two-layer cron plus watchdog monitoring pattern for openclaw on ubuntu or other systemd-based linux hosts. use when you need durable recurring checks, post-fix stability observation, gateway health validation, worker-log monitoring, or external fallback monitoring that continues even if the gateway or internal cron becomes unhealthy.
---

Implement a two-layer operational safety net for OpenClaw on Ubuntu/systemd hosts.

## Core model

Use two layers:
1. OpenClaw cron for normal in-gateway scheduling.
2. systemd timer watchdog for external fallback when gateway health itself is in question.

Do not use heartbeat as a scheduler replacement.

## Included resources
- `references/cron-watchdog-runbook.md`: deployment rationale and validation steps.
- `references/watchdog-checks.md`: exact checks and exit criteria.
- `scripts/openclaw_gateway_watchdog.sh`: health and worker-log checker.
- `scripts/install_watchdog_systemd.sh`: installs the service and timer.

## How to use

### 1. Install the watchdog
Run as root:

```bash
bash scripts/install_watchdog_systemd.sh
```

This installs:
- `/usr/local/bin/openclaw-gateway-watchdog.sh`
- `/etc/systemd/system/openclaw-gateway-watchdog.service`
- `/etc/systemd/system/openclaw-gateway-watchdog.timer`

### 2. Validate installation
Run:

```bash
systemctl daemon-reload
systemctl enable --now openclaw-gateway-watchdog.timer
systemctl status openclaw-gateway-watchdog.timer --no-pager
systemctl list-timers --all | grep openclaw-gateway-watchdog
journalctl -u openclaw-gateway-watchdog.service -n 50 --no-pager
```

### 3. Use OpenClaw cron for internal recurring jobs
Use OpenClaw cron for scheduled tasks that should live inside the gateway, such as recurring PM reminders or periodic hygiene prompts.

### 4. Use the watchdog for infrastructure assurance
The watchdog should be treated as the fallback layer that checks:
- gateway health
- new `missing status.json`
- repeated `accepted and moved` for the same task id
- worker-log path availability

## Closure standard

Treat the watchdog deployment as complete only when:
- the timer is active
- the service runs successfully
- the log file exists and shows checks running
- the configured lookback window is scanning the worker log
