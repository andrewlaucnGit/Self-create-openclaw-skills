# Cron + Watchdog Runbook

## Goal

Provide a durable two-layer operational safety net:
- OpenClaw cron for normal recurring checks
- systemd watchdog for external fallback and health enforcement

## Layer 1: OpenClaw cron

Use OpenClaw cron for scheduled in-gateway tasks such as:
- daily hygiene review prompts
- periodic PM status reminders
- recurring stability audits that should run inside OpenClaw

Recommended examples:
- `openclaw cron list`
- `openclaw cron status <job-id>`
- `openclaw cron runs --id <job-id>`

Prefer cron for runs that should persist under `~/.openclaw/cron/` and survive gateway restarts.

## Layer 2: systemd watchdog

Use the external watchdog for checks that must still work when the gateway is unhealthy.

Suggested schedule:
- every 15 minutes for health checks on unstable systems
- every 30 to 60 minutes on stable systems

## Recommended Ubuntu deployment

Install:
- `/usr/local/bin/openclaw-gateway-watchdog.sh`
- `/etc/systemd/system/openclaw-gateway-watchdog.service`
- `/etc/systemd/system/openclaw-gateway-watchdog.timer`

Enable with:
- `systemctl daemon-reload`
- `systemctl enable --now openclaw-gateway-watchdog.timer`

Validate with:
- `systemctl status openclaw-gateway-watchdog.timer --no-pager`
- `systemctl list-timers --all | grep openclaw-gateway-watchdog`
- `journalctl -u openclaw-gateway-watchdog.service -n 50 --no-pager`

## Why both layers matter

- cron gives first-class scheduled jobs, run history, and job persistence
- watchdog protects you when cron or the gateway itself is the thing failing
- use cron for business logic and watchdog for infrastructure assurance
