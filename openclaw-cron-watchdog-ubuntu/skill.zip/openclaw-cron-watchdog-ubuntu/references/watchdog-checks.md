# Watchdog Checks

## Default checks

The watchdog should check all of the following:

1. gateway endpoint responds
2. worker log exists
3. no new `missing status.json` in the configured lookback window
4. no repeated `accepted and moved` for the same task id in the configured lookback window

## Suggested environment variables

- `OPENCLAW_GATEWAY_URL`
- `OPENCLAW_WORKER_LOG`
- `OPENCLAW_WATCHDOG_LOG`
- `OPENCLAW_WATCHDOG_LOOKBACK_HOURS`

## Exit rules

Exit `0` only when:
- gateway health is good
- worker log exists
- `missing status.json` count is zero
- repeated task-id count is zero

Exit non-zero when any of the above fail.
