#!/usr/bin/env bash
set -euo pipefail

GATEWAY_URL="${OPENCLAW_GATEWAY_URL:-http://127.0.0.1:18789/health}"
WORKER_LOG="${OPENCLAW_WORKER_LOG:-/root/.openclaw/shared_pool/worker/logs/it_task_worker.log}"
WATCHDOG_LOG="${OPENCLAW_WATCHDOG_LOG:-/var/log/openclaw-gateway-watchdog.log}"
LOOKBACK_HOURS="${OPENCLAW_WATCHDOG_LOOKBACK_HOURS:-4}"

mkdir -p "$(dirname "$WATCHDOG_LOG")"
touch "$WATCHDOG_LOG"

log() {
  echo "[$(date '+%F %T')] $*" | tee -a "$WATCHDOG_LOG"
}

window_start="$(date -d "-${LOOKBACK_HOURS} hours" '+%F %T')"

health_ok=0
if command -v curl >/dev/null 2>&1; then
  if curl -fsS --max-time 5 "$GATEWAY_URL" >/dev/null; then
    health_ok=1
  fi
fi

if [[ $health_ok -eq 1 ]]; then
  log "gateway health check ok: $GATEWAY_URL"
else
  log "gateway health check failed: $GATEWAY_URL"
fi

missing_count=0
repeat_count=0
if [[ -f "$WORKER_LOG" ]]; then
  missing_count=$(awk -v start="[$window_start]" '$0 >= start && /missing status\.json/ {c++} END {print c+0}' "$WORKER_LOG")
  repeat_count=$(awk -v start="[$window_start]" '$0 >= start && /accepted and moved:/ {sub(/^.*accepted and moved: /, "", $0); count[$0]++} END {bad=0; for (k in count) if (count[k] > 1) bad++; print bad+0}' "$WORKER_LOG")
  log "worker log lookback start=$window_start missing_status_json=$missing_count repeated_task_ids=$repeat_count"
else
  log "worker log missing: $WORKER_LOG"
  exit 2
fi

if [[ $health_ok -eq 0 || $missing_count -gt 0 || $repeat_count -gt 0 ]]; then
  exit 1
fi

exit 0
