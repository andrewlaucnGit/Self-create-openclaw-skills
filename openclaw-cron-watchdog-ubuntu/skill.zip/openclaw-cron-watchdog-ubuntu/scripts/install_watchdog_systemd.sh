#!/usr/bin/env bash
set -euo pipefail

SCRIPT_SRC="$(cd "$(dirname "$0")" && pwd)/openclaw_gateway_watchdog.sh"
SCRIPT_DST="/usr/local/bin/openclaw-gateway-watchdog.sh"
SERVICE_DST="/etc/systemd/system/openclaw-gateway-watchdog.service"
TIMER_DST="/etc/systemd/system/openclaw-gateway-watchdog.timer"

if [[ $EUID -ne 0 ]]; then
  echo "run as root"
  exit 1
fi

install -m 0755 "$SCRIPT_SRC" "$SCRIPT_DST"

cat > "$SERVICE_DST" <<'SERVICE'
[Unit]
Description=OpenClaw Gateway Watchdog
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
Environment=OPENCLAW_GATEWAY_URL=http://127.0.0.1:18789/health
Environment=OPENCLAW_WORKER_LOG=/root/.openclaw/shared_pool/worker/logs/it_task_worker.log
Environment=OPENCLAW_WATCHDOG_LOG=/var/log/openclaw-gateway-watchdog.log
Environment=OPENCLAW_WATCHDOG_LOOKBACK_HOURS=4
ExecStart=/usr/local/bin/openclaw-gateway-watchdog.sh
SERVICE

cat > "$TIMER_DST" <<'TIMER'
[Unit]
Description=Run OpenClaw Gateway Watchdog every 15 minutes

[Timer]
OnBootSec=2m
OnUnitActiveSec=15m
AccuracySec=1m
Persistent=true
Unit=openclaw-gateway-watchdog.service

[Install]
WantedBy=timers.target
TIMER

systemctl daemon-reload
systemctl enable --now openclaw-gateway-watchdog.timer

echo "installed: $SCRIPT_DST"
echo "installed: $SERVICE_DST"
echo "installed: $TIMER_DST"
systemctl status openclaw-gateway-watchdog.timer --no-pager || true
