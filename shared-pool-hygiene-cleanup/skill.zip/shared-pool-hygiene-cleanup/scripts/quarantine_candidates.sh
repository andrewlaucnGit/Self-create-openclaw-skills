#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "usage: $0 <quarantine-dir> <path1> [path2 ...]"
  exit 1
fi

QUARANTINE_DIR="$1"
shift
mkdir -p "$QUARANTINE_DIR"

for p in "$@"; do
  if [[ -e "$p" ]]; then
    base="$(basename "$p")"
    dst="$QUARANTINE_DIR/$base"
    mv "$p" "$dst"
    echo "moved: $p -> $dst"
  else
    echo "missing: $p"
  fi
done
