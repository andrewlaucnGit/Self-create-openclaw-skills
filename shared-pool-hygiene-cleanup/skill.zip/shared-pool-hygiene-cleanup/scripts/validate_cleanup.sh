#!/usr/bin/env bash
set -euo pipefail

checks=(
  "/root/.openclaw/shared_pool/worker/it_task_worker.sh"
  "/root/.openclaw/shared_pool/worker/fix_task_persistence.sh"
  "/root/.openclaw/shared_pool/tasks/in_progress"
)

for p in "${checks[@]}"; do
  if [[ -e "$p" ]]; then
    echo "ok: $p"
  else
    echo "missing: $p"
    exit 1
  fi
done

systemctl status it-task-worker.timer --no-pager >/dev/null
systemctl status it-task-worker.service --no-pager >/dev/null

echo "validation ok"
