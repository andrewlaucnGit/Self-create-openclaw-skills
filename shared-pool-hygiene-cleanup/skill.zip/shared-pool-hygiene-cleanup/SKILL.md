---
name: shared-pool-hygiene-cleanup
description: safely inspect, quarantine, review, and optionally delete old backup, disabled, and recovery artifacts in openclaw deployments without removing live files. use when you need a reusable hygiene workflow for .bak, .disable, quarantine, rollback planning, batch deletion, and post-cleanup validation on shared_pool, workspace, and related openclaw directories.
---

Perform safe system hygiene for OpenClaw deployments.

## Core model

Always follow this sequence:
1. inspect
2. classify
3. quarantine
4. validate
5. optionally do a second-stage deletion

Do not jump straight to deletion.

## Included resources
- `references/cleanup-runbook.md`: quarantine-first workflow.
- `references/cleanup-acceptance-checklist.md`: acceptance standards.
- `references/AGENTS.md`: PM/IT task and evidence rules for hygiene tasks.
- `references/HEARTBEAT.md`: when recurring monitoring is or is not needed.
- `scripts/quarantine_candidates.sh`: moves candidate files into a quarantine directory.
- `scripts/validate_cleanup.sh`: verifies live paths and services remain healthy.

## How to use

### 1. Identify candidates
Candidates should be older `.bak`, `.disable`, `.disabled`, and obviously stale recovery artifacts.

Default protected items:
- current live worker scripts
- current gateway config
- current in-progress task artifacts
- recent backups still needed for rollback
- anything with unclear purpose

### 2. Quarantine before deletion
Run `scripts/quarantine_candidates.sh` with explicit paths or patterns.

### 3. Validate immediately after quarantine
Run `scripts/validate_cleanup.sh` to ensure:
- worker scripts still exist
- active tasks are still visible
- key service/timer units remain healthy

### 4. Only then do final disposition
Treat final deletion as a separate stage. Delete in small batches with a validation step after each batch.

## Evidence requirements
For each hygiene task, produce:
- candidate list with reasons and risk
- quarantine path
- execution commands
- validation outputs
- rollback method
