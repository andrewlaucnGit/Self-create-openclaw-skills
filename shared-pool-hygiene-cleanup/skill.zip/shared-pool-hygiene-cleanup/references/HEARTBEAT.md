# HEARTBEAT.md

Cleanup tasks are usually one-time execution tasks.

Do not add recurring monitoring unless:
- the operator explicitly wants drift checks
- the environment is still unstable
- PM or IT commits to follow-up observations

If recurring follow-up is needed, use OpenClaw cron or a systemd timer, not heartbeat alone.
