# Cleanup Runbook

## Goal

Reduce clutter and ambiguity from old backup and disabled artifacts without harming live paths.

## Stage 1: Inspect

Look in these areas first:
- `/root/.openclaw/shared_pool`
- `/root/.openclaw/workspace`
- `/root/.openclaw/workspaces/it`
- `/root/.openclaw`

Candidate patterns:
- `*.bak`
- `*.disable`
- `*.disabled`
- stale recovery directories

## Stage 2: Quarantine

Move candidates into a dated quarantine directory such as:
- `/root/.openclaw/cleanup-quarantine-YYYY-MM-DD/`

Do not delete immediately.

## Stage 3: Validate

After quarantine, verify:
- worker scripts still exist
- current tasks remain readable
- service/timer health is normal

## Stage 4: Final disposition

Delete only in explicit batches.
Keep a record of:
- deleted paths
- retained paths
- reasons
- validation outputs after each batch
