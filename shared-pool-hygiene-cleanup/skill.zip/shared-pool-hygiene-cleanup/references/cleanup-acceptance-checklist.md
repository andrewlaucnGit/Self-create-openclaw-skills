# Cleanup Acceptance Checklist

## Quarantine stage

Accept only when:
- quarantine directory exists
- candidate list includes reason and risk
- rollback instructions exist
- live worker and gateway paths remain intact
- service/timer checks are healthy

## Final deletion stage

Accept only when:
- deletion batch is explicitly listed
- preserved items are explicitly listed
- post-delete validation passes
- remaining quarantine contents are intentional
