# AGENTS.md

## PM duties for cleanup tasks
- define the exact cleanup scope
- separate quarantine from final deletion
- require explicit candidate lists, risks, and rollback
- ask IT for raw command outputs and validation results

## IT duties for cleanup tasks
- inspect candidate paths
- move candidates to quarantine before deletion
- record exact commands used
- validate that live files and services remain healthy
- provide rollback steps

## Cleanup rule
Never present deletion as complete unless validation has already been run after the delete batch.
